This file is for you to describe the nipap-www application. Typically
you would include information such as the information below:

Installation and Setup
======================

Install ``nipap-www`` using easy_install::

    easy_install nipap-www

Make a config file as follows::

    paster make-config nipap-www config.ini

Tweak the config file as appropriate and then setup the application::

    paster setup-app config.ini

Then you are ready to go.
